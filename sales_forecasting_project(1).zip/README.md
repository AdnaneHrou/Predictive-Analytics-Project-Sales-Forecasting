
# Sales Forecasting Project

This project aims to build a predictive model using machine learning techniques to forecast sales. The project involves data collection, preprocessing, exploratory data analysis, model building, and evaluation.

## Tools Used
- Python
- scikit-learn
- pandas
- Jupyter Notebook

## Project Structure
- `data/`: Contains the dataset.
- `sales_forecasting.ipynb`: Jupyter Notebook with the project code and documentation.

## How to Run
1. Clone the repository.
2. Install the required packages: `pip install -r requirements.txt`
3. Open `sales_forecasting.ipynb` in Jupyter Notebook.
4. Run the cells sequentially.

## Results
The model achieved an RMSE of X on the test set.
